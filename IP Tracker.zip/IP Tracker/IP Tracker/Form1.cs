using ServiceStack;
using ServiceStack.Text;
using System.Net.Http.Headers;
using System.Text.Json;

namespace IP_Tracker
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string url = "http://ip-api.com/json/" + textBox1.Text;
                if(textBox1.Text != "")
                {
                    Geolocation geoInfo = url.GetJsonFromUrl().FromJson<Geolocation>();

                    label1.Text = "Status: " + geoInfo.status;
                    label2.Text = "Continent: " + geoInfo.continent;
                    label3.Text = "Country: " + geoInfo.country;
                    label4.Text = "Region: " + geoInfo.region;
                    label5.Text = "City: " + geoInfo.city;
                    label6.Text = "Zip: " + geoInfo.zip;
                    label7.Text = "Latitude: " + geoInfo.lat;
                    label8.Text = "Longitude: " + geoInfo.lon;
                    label9.Text = "ISP: " + geoInfo.isp;
                }
                else
                {
                    MessageBox.Show("Enter valid IP");
                }
                
            }
            catch (Exception)
            {
                MessageBox.Show("An error occured");
            }


            
        }
    }

    public class Geolocation
    {
        public string status { get; set; }
        public string continent { get; set; }
        public string country { get; set; }
        public string region { get; set; }
        public string city { get; set; }
        public string zip { get; set; }
        public string lat { get; set; }
        public string lon { get; set; }
        public string isp { get; set; }

    }
}